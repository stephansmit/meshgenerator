/*
 * unstruct.cpp
 *
 *  Created on: Mar 19, 2012
 *      Author: enrico
 */
#include "unstruct.h"

//=============================================
//        UNSTRUCTMESH CLASS FUNCTIONS
//=============================================
UNSTRUCTMESH & UNSTRUCTMESH::operator+=(const UNSTRUCTMESH &mesh)
{
	// TO DO:
	// CAN BE RE-WRITTEN USING ALREADY nodes, elem_i AND elem_v (NO NEED FOR *_new)

	// NODES
	deque<NODE> nodes_new;
	for (int i=0; i<nno_i; i++)        		              nodes_new.push_back(nodes[i]);
	for (int i=0; i<mesh.nno_i; i++)                    nodes_new.push_back(mesh.nodes[i]);
	for (int i=nno_i; i<nodes.size(); i++)              nodes_new.push_back(nodes[i]);
	for (int i=mesh.nno_i; i<mesh.nodes.size(); i++)    nodes_new.push_back(mesh.nodes[i]);

	// ELEM_I
	deque<int> elem_i_new;
	for (int i=0; i<nel_i; i++)                             elem_i_new.push_back(elem_i[i]);
	for (int i=0; i<mesh.nel_i; i++)                        elem_i_new.push_back(mesh.elem_i[i]+elem_i[nel_i]);
	for (int i=nel_i; i<elem_i.size()-1; i++)               elem_i_new.push_back(elem_i[i]+mesh.elem_i[mesh.nel_i]);
	for (int i=mesh.nel_i; i<=mesh.elem_i.size()-1; i++)    elem_i_new.push_back(mesh.elem_i[i]+(int)elem_v.size());

	// ELEM_V
	deque<int> elem_v_new;
	for (int i=0; i<elem_i[nel_i]; i++)
		if (elem_v[i]>=nno_i)			          elem_v_new.push_back(elem_v[i]+mesh.nno_i);
		else                                elem_v_new.push_back(elem_v[i]);

	for (int i=0; i<mesh.elem_i[mesh.nel_i]; i++)
		if (mesh.elem_v[i]>=mesh.nno_i)			elem_v_new.push_back(mesh.elem_v[i]+nodes.size());
		else                                elem_v_new.push_back(mesh.elem_v[i]+nno_i);

	for (int i=elem_i[nel_i]; i<elem_v.size(); i++)
		if (elem_v[i]>=nno_i)         			elem_v_new.push_back(elem_v[i]+mesh.nno_i);
		else                                elem_v_new.push_back(elem_v[i]);

	for (int i=mesh.elem_i[mesh.nel_i]; i<mesh.elem_v.size(); i++)
		if (mesh.elem_v[i]>=mesh.nno_i)			elem_v_new.push_back(mesh.elem_v[i]+nodes.size());
		else                                elem_v_new.push_back(mesh.elem_v[i]+nno_i);

	nno_i += mesh.nno_i;
	nel_i += mesh.nel_i;
	nodes = nodes_new;
	elem_i = elem_i_new;
	elem_v = elem_v_new;

	removeDoublePoints();

	return *this;
}

UNSTRUCTMESH UNSTRUCTMESH::operator+(const UNSTRUCTMESH &unstructMesh)
{
  UNSTRUCTMESH tmp = *this;
  tmp += unstructMesh;
  return tmp;
}

//UNSTRUCTMESH & UNSTRUCTMESH::operator-=(const UNSTRUCTMESH &mesh)
//{
//	// Define the POLYGON boundary
//	POLYGON extPoly(mesh.extBoundary);
//
//	extPoly.writeCtrPts("test.dat");
//
//	deque<int> nodesInside;
//
//	// list all the nodes which are inside the external boundary of "mesh"
//	for (int i=0; i<nodes.size(); i++)
//		if (extPoly.pointInsidePolygon(nodes[i].pt)==true)
//			nodesInside.push_back(i);
//
//	// remove all the elements which contain at least one of the nodesInside
//	int e=0; bool del=false;
//	while (e<elems.size())
//	{
//		for (int i=0; i<nodesInside.size(); i++)
//			for (int j=0; j<elems[e].node.size(); j++)
//				if (elems[e].node[j]==nodesInside[i])
//				{
//					elems.erase(elems.begin() + e);
//					del = true;
//				}
//
//		if (del==false)	e++;
//		del=false;
//	}
//
//	return *this;
//}

//UNSTRUCTMESH UNSTRUCTMESH::operator-(const UNSTRUCTMESH &unstructMesh)
//{
//	UNSTRUCTMESH tmp = *this;
//	tmp -= unstructMesh;
//	return tmp;
//}


void UNSTRUCTMESH::moveBoundaryNodesEnd(deque<POINT> boundPts)
{
	for (int i=0; i<(int)boundPts.size(); i++)
	{
		int ind=0;
		while ((ind<nodes.size()) && (nodes[ind].pt != boundPts[i])) ind++;
		if (!(ind == nodes.size())) moveNodeEnd(ind);
	}
	nno_i = nodes.size()-boundPts.size();
}

void UNSTRUCTMESH::moveNodeEnd(int ind)
{
  // move node to the end of the deque
  NODE tmpNode = nodes[ind];

  nodes.erase(nodes.begin()+ind);
  nodes.push_back(tmpNode);

  // update nodes in elements;
  for (int i=0; i<elem_v.size(); i++)
    if (elem_v[i]==ind)      elem_v[i] = nodes.size()-1;
    else if (elem_v[i]>ind)  elem_v[i]--;
}


void UNSTRUCTMESH::moveBoundaryElementsEnd(deque<POINT> boundPts)
{
	int elemMoved = 0;
	for (int i=0; i<boundPts.size()-1; i++)
	{
		int ind=0;

		while (ind<elem_i.size()-1-elemMoved)
		{
			int count = 0;
			int nNodes = elem_i[ind+1]-elem_i[ind];

			for (int n=0; n<nNodes; n++)
				if (nodes[elem_v[elem_i[ind]+n]].pt==boundPts[i])	count++;

			if (count>0)
				{moveElementEnd(ind); elemMoved++;}
			else ind++;
		}
	}
	nel_i = elem_i.size()-1-elemMoved; // -1 because the last i is not an element
}

void UNSTRUCTMESH::moveElementEnd(int ind)
{
	// move node to the end of the deque
	int nNodes = elem_i[ind+1]-elem_i[ind];

	// save the element into a temp variable
	deque<int> tmpElement;
	for (int i=0; i<nNodes; i++)
		tmpElement.push_back(elem_v[elem_i[ind]+i]);

	// remove element from the list
	for (int i=0; i<nNodes; i++)
		elem_v.erase(elem_v.begin() + elem_i[ind]);
	// remove element from elem_i list
	elem_i.erase(elem_i.begin()+ind);

	// update startNewElem from ind to the end
	for (int i=ind; i<elem_i.size(); i++)
		elem_i[i] -= nNodes;

	// insert the element at the end of the list
	for (int i=0; i<nNodes; i++)
		elem_v.push_back(tmpElement[i]);

	// insert elem_i for the last element
	elem_i.push_back(elem_i[elem_i.size()-1]+nNodes);
}


void UNSTRUCTMESH::removeDoublePoints()
{
	// Based on how meshes are added, double points can be on the boundaries only
	for (int i=nno_i; i<nodes.size(); i++)
		for (int j=i+1; j<nodes.size(); j++)
			if (nodes[j].pt == nodes[i].pt)
			{
				nodes.erase(nodes.begin()+j);
				// change nodes index in the boundary elements
				for (int e=elem_i[nel_i]; e<elem_v.size(); e++)
					if (elem_v[e]==j)	elem_v[e] = i;
					else if (elem_v[e]>j) elem_v[e]--;
			}

//  for (int i=0; i<nodes.size(); i++)
//    for (int j=i+1; j<nodes.size(); j++)
//      if (nodes[j].pt == nodes[i].pt)
//      {
//        nodes.erase(nodes.begin()+j);
//        // change nodes index in the boundary elements
//        for (int e=0; e<elem_v.size(); e++)
//          if (elem_v[e]==j) elem_v[e] = i;
//          else if (elem_v[e]>j) elem_v[e]--;
//      }

	// nodes and elements that are now internal should be put outside the boundary list
}



void UNSTRUCTMESH::findNodeNeighbors()
{
	// identify neighbours of every point
	for (int i=0; i<nodes.size(); i++)
		for (int j=0; j<elem_i.size()-1; j++)
		{
			for (int n=0; n<elem_i[j+1]-elem_i[j]; n++)
				if (elem_v[elem_i[j]+n] == i)
					for (int nn=0; nn<elem_i[j+1]-elem_i[j]; nn++)
						nodes[i].neig.push_back(elem_v[elem_i[j]+nn]);
		}

	// sort nodes indexes and remove duplicates
	for (int i=0; i<nodes.size(); i++)
	{
		nodes[i].neig.sort();
		nodes[i].neig.unique();
		nodes[i].neig.remove(i);
	}

	for (int i=0; i<nodes.size(); i++)
		for (int j=0; j<elems.size(); j++)
		{
			for (int n=0; n<elems[j].node.size(); n++)
				if (elems[j].node[n] == i)
					for (int nn=0; nn<elems[j].node.size(); nn++)
						nodes[i].neig.push_back(elems[j].node[nn]);
		}

	// sort nodes indexes and remove duplicates
	for (int i=0; i<nodes.size(); i++)
	{
		nodes[i].neig.sort();
		nodes[i].neig.unique();
		nodes[i].neig.remove(i);
	}
}

void UNSTRUCTMESH::setMarker(const deque<POINT> &points, int marker)
{
	for (int i=0; i<points.size(); i++)
		for (int j=0; j<nodes.size(); j++)
		{
			if (nodes[j].pt == points[i])
				nodes[j].marker = marker;
			else nodes[j].marker = 0;
		}
}


void UNSTRUCTMESH::replacePoints(const deque<POINT> &oldPoints, const deque<POINT> &newPoints)
{
	for (int i=0; i<newPoints.size(); i++)
		for (int j=0; j<nodes.size(); j++)
				if (nodes[j].pt == oldPoints[i])
					nodes[j].pt = newPoints[i];
}



// Laplacian smoother
void UNSTRUCTMESH::smoothMesh(int maxit, double tol)
{
	deque<POINT> temp_points(nodes.size());
	for (int j=0; j<nodes.size(); j++)
		temp_points[j] = nodes[j].pt;

	int n = 0;
	double err = 1.0;

	while ((n<maxit) && (err>tol))
	{
		double diff = 0.0;

		for (int j=0; j<nodes.size(); j++)
			if (nodes[j].marker != 1)
			{
				POINT pt(0.0, 0.0, 0.0);
				for (list<int>::iterator it = nodes[j].neig.begin(); it!=nodes[j].neig.end(); ++it)           pt += nodes[*it].pt;
				POINT delta =  pt/(double)nodes[j].neig.size() - nodes[j].pt;
//          if (mag(delta)>diff)
//          	diff = mag(delta);
				diff += mag(delta);
				temp_points[j] = nodes[j].pt + 0.6*delta;
			}

		n++;
		err = diff;

		if (n%100 == 0)        printf("laplace iter = %d\t %.4le\n", n, err);

		// update all the points x and y
		for (int j=0; j<nodes.size(); j++)
			if (nodes[j].marker != 1)
				nodes[j].pt = temp_points[j];
	}

	if (err>tol)
		printf("smoother not converged \n");
	printf("iter = %d, err = %1.5le\n", n, err);
}

void UNSTRUCTMESH::writeMarkedNodes(const char * name, int marker)
{
	FILE *fp = fopen(name, "wt");
	for (int i=0; i<nodes.size(); i++)
	{
		if (nodes[i].marker == marker)
			fprintf(fp, "%1.10le\t%1.10le\t%1.10le\n", nodes[i].pt.x, nodes[i].pt.y, nodes[i].pt.z);
	}
	fclose(fp);
}

void UNSTRUCTMESH::writeTecplot(const char * name, int ndim, bool onlyBoundary)
{
	FILE *fp;
	if ((fp = fopen(name, "wt")) == NULL)
	{
		printf("couldn't open %s for writing\n", name);
		return;
	}

	string elemtype;
	if      (ndim == 2) elemtype = "FEQUADRILATERAL";
	else if (ndim == 3) elemtype = "FEBRICK";
	else
	{
		printf("ERROR: NUMBER OF DIMENSIONS NOT CORRECT!\n");
		throw(-100);
	}

	fprintf(fp, "TITLE=\"mesh\"\n");
	fprintf(fp, "VARIABLES=\"X\" \"Y\" \"Z\"\n");
	if (onlyBoundary==true)
		fprintf(fp, "ZONE N=%d, E=%d, DATAPACKING=POINT, ZONETYPE=%s\n", (int)nodes.size(), (int)(elem_i.size()-1-nel_i), elemtype.c_str());
	else	fprintf(fp, "ZONE N=%d, E=%d, DATAPACKING=POINT, ZONETYPE=%s\n", (int)nodes.size(), (int)(elem_i.size()-1), elemtype.c_str());

//  int iStart = 0;
//  if (onlyBoundary==true)
//    iStart = nno_i;

	for (int i=0; i<nodes.size(); i++)
		fprintf(fp, "%1.10le\t%1.10le\t%1.10le\n", nodes[i].pt.x, nodes[i].pt.y, nodes[i].pt.z);
	fprintf(fp, "\n");


	int iStart = 0;
	if (onlyBoundary==true)
		iStart = nel_i;


//  if (onlyBoundary==true)
//  {
//    printf("number: %d\n",nno_i);
//    for (int i=elem_i[iStart]; i<elem_v.size(); i++)
//      elem_v[i] -= nno_i;
//  }

	for (int i=iStart; i<elem_i.size()-1; i++)
	{
		int nNodes = elem_i[i+1]-elem_i[i];

		if (nNodes == 3)
			fprintf(fp, "%d\t%d\t%d\t%d\n", elem_v[elem_i[i]]+1, elem_v[elem_i[i]]+1, elem_v[elem_i[i]+1]+1, elem_v[elem_i[i]+2]+1);

		else if (nNodes == 4)
			fprintf(fp, "%d\t%d\t%d\t%d\n", elem_v[elem_i[i]]+1, elem_v[elem_i[i]+1]+1, elem_v[elem_i[i]+2]+1, elem_v[elem_i[i]+3]+1);

		else if (nNodes == 6)
			fprintf(fp, "%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n", elem_v[elem_i[i]]+1, elem_v[elem_i[i]]+1, elem_v[elem_i[i]+1]+1, elem_v[elem_i[i]+2]+1,
			                                                elem_v[elem_i[i]+3]+1, elem_v[elem_i[i]+3]+1, elem_v[elem_i[i]+4]+1, elem_v[elem_i[i]+5]+1);

		else if (nNodes == 8)
      fprintf(fp, "%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n", elem_v[elem_i[i]]+1, elem_v[elem_i[i]+1]+1, elem_v[elem_i[i]+2]+1, elem_v[elem_i[i]+3]+1,
                                                      elem_v[elem_i[i]+4]+1, elem_v[elem_i[i]+5]+1, elem_v[elem_i[i]+6]+1, elem_v[elem_i[i]+7]+1);

    else {printf("ERROR DIMENSIONS: %d\t i: %d\n", nNodes, i); throw(-333);}
	}
	fclose(fp);
}

void UNSTRUCTMESH::writeGambitNeu(const char *name, int ndim, bool onlyBoundary)
{
	FILE *fp;
	if ((fp = fopen(name, "wt")) == NULL)
	{
		printf("couldn't open %s for writing\n", name);
		return;
	}

	fprintf(fp, "        CONTROL INFO 2.4.6\n");
	fprintf(fp, "** GAMBIT NEUTRAL FILE\n");
	fprintf(fp, "NONAME\n");
	fprintf(fp, "PROGRAM:                Gambit     VERSION:  2.4.6\n");
	fprintf(fp, " 1 Jan 2012    00:00:00\n");
	fprintf(fp, "     NUMNP     NELEM     NGRPS    NBSETS     NDFCD     NDFVL\n");
  if (onlyBoundary==true)
    fprintf(fp, "%10d%10d         1         1%10d%10d\n", (int)nodes.size(), (int)(elem_i.size()-1-nel_i), ndim, ndim);
  else fprintf(fp, "%10d%10d         1         1%10d%10d\n", (int)nodes.size(), (int)(elem_i.size()-1), ndim, ndim);
	fprintf(fp, "ENDOFSECTION\n");

//	int iStart = 0;
//  if (onlyBoundary==true)
//    iStart = nno_i;


	fprintf(fp, "   NODAL COORDINATES 2.4.6\n");
	if (ndim == 2)
		for (int i=0; i<nodes.size(); i++)
			fprintf(fp, "%10d%20.11le%20.11le\n", i+1, nodes[i].pt.x, nodes[i].pt.y);
	else if (ndim == 3)
		for (int i=0; i<nodes.size(); i++)
			fprintf(fp, "%10d%20.11le%20.11le%20.11le\n", i+1, nodes[i].pt.x, nodes[i].pt.y, nodes[i].pt.z);
	else
	{
		printf("ERROR: NUMBER OF DIMENSIONS NOT CORRECT!\n");
		throw(-100);
	}
	fprintf(fp, "ENDOFSECTION\n");

	fprintf(fp, "      ELEMENTS/CELLS 2.4.6\n");

	int cStart = 0;
  if (onlyBoundary==true)
    cStart = nel_i;

	for (int c=cStart; c<elem_i.size()-1; c++)
	{
		int nNodes = elem_i[c+1]-elem_i[c];

		if (nNodes == 3)
		{
			fprintf(fp, "%8d%3d%3d ", c+1, NTYPE_TRI, NDP_TRI);
			for (int n=elem_i[c]; n<elem_i[c+1]; n++)
				fprintf(fp, "%8d", elem_v[n]+1);
			fprintf(fp, "\n");
		}
		else if (nNodes == 4)
		{
			fprintf(fp, "%8d%3d%3d ", c+1, NTYPE_QUAD, NDP_QUAD);
			for (int n=elem_i[c]; n<elem_i[c+1]; n++)
				fprintf(fp, "%8d", elem_v[n]+1);
			fprintf(fp, "\n");
		}

		else if (nNodes == 6)
    {
      fprintf(fp, "%8d%3d%3d ", c+1, NTYPE_PRISM, NDP_PRISM);
      for (int n=elem_i[c]; n<elem_i[c+1]; n++)
        fprintf(fp, "%8d", elem_v[n]+1);
      fprintf(fp, "\n");
    }

		else if(nNodes == 8)
    {
      fprintf(fp, "%8d%3d%3d ", c+1, NTYPE_BRICK, NDP_BRICK);
      fprintf(fp, "%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n", elem_v[elem_i[c]]+1, elem_v[elem_i[c]+1]+1, elem_v[elem_i[c]+3]+1, elem_v[elem_i[c]+2]+1,
                                                            elem_v[elem_i[c]+4]+1, elem_v[elem_i[c]+5]+1, elem_v[elem_i[c]+7]+1, elem_v[elem_i[c]+6]+1);
    }

		else {printf("ERROR DIMENSIONS: %d\t i: %d\n", nNodes, c); throw(-333);}

	}
	fprintf(fp, "ENDOFSECTION\n");
	fclose(fp);

	printf("\n GAMBIT file %s written.\n", name);
}


void UNSTRUCTMESH::writeFluentMsh(char * filename, int nbl)//, block *bl)
{
  FILE * fp;

  printf(" > starting to write fluent case file: %s\n", filename);

  if ( (fp=fopen(filename,"w"))==NULL ) {
    printf(" > could not open file %s\n", filename);
    exit(-1);
  }

  fprintf(fp,"(0 \"Project to Fluent\")\n");
  fprintf(fp,"\n");
  fprintf(fp,"(0 \"Dimensions:\")\n");
  fprintf(fp,"(2 3)\n");
  fprintf(fp,"\n");

  //
  // header and global dimensions
  //

  int vertices = 0, elements = 0, nfaces = 0;

  for (int n=0; n<nbl; ++n)
  {
    vertices += 0;//(bl[n].imax+1)*(bl[n].jmax+1)*(bl[n].kmax+1);
    elements += 0;//bl[n].imax*bl[n].jmax*bl[n].kmax;
    nfaces += 0;//bl[n].imax*bl[n].jmax*(bl[n].kmax+1)+bl[n].imax*(bl[n].jmax+1)*bl[n].kmax+(bl[n].imax+1)*bl[n].jmax*bl[n].kmax;
  }

  fprintf(fp,"(0 \"Grid:\")\n");
  fprintf(fp,"\n");
  fprintf(fp,"(12 (0 %x %x 0))\n",1, elements);
  fprintf(fp,"(13 (0 %x %x 0))\n",1, nfaces);
  fprintf(fp,"(10 (0 %x %x 0 3))\n",1, vertices);
  fprintf(fp,"\n");

  //
  // cells
  //
  int cv_element_type = 7; // polyhedra = 7
  int cv_type = 1; // active = 1 - inactive = 32
  char this_zone[128];
  sprintf(this_zone,"fluid");
  fprintf(fp,"(0 \"Cells:\")\n");
  fprintf(fp,"(12 (%x %x %x %x %x))\n", 4001,1,elements,cv_type,cv_element_type);
  fprintf(fp,"(45 (%d fluid %s)())\n",  4001,this_zone);
  fprintf(fp,"\n");

  //
  // start of faces
  //
  fprintf(fp,"(0 \"Faces:\")\n");
  fprintf(fp,"\n");

/*
  //
  // faces
  //
  int fa_element_type = 5; // 5 is polygonal; 4 is quadrilateral

  int n = 0, i, j, k;
  int this_zone_id = 11;
  int fa_offset = 1;
  int fa_number = bl[n].imax*bl[n].jmax;
  fprintf(fp,"(13 (%x %x %x %x %x)(\n", this_zone_id, fa_offset, fa_number, (int)FLUENT_TYPE_WALL, fa_element_type);
  k = 0;
  for (i=0; i<bl[n].imax; ++i)
    for (j=0; j<bl[n].jmax; ++j)
    {
      fprintf(fp,"%x ", 4); // number of nodes of face
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+0) + k + 1);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+1) + (bl[n].kmax+1)*(j+0) + k + 1);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+1) + (bl[n].kmax+1)*(j+1) + k + 1);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+1) + k + 1);
      fprintf(fp,"%x %x\n", bl[n].jmax*bl[n].kmax*i + bl[n].kmax*j + k + 1, 0);
    }
  fprintf(fp, "))\n");

  this_zone_id++;
  fa_offset = fa_number+1;
  fa_number = fa_offset + bl[n].imax*bl[n].jmax-1;
  fprintf(fp,"(13 (%x %x %x %x %x)(\n", this_zone_id, fa_offset, fa_number, (int)FLUENT_TYPE_WALL, fa_element_type);
  k = bl[n].kmax;
  for (i=0; i<bl[n].imax; ++i)
    for (j=0; j<bl[n].jmax; ++j)
    {
      fprintf(fp,"%x ", 4); // number of nodes of face
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+0) + k + 1);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+1) + k + 1);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+1) + (bl[n].kmax+1)*(j+1) + k + 1);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+1) + (bl[n].kmax+1)*(j+0) + k + 1);
      fprintf(fp,"%x %x\n", bl[n].jmax*bl[n].kmax*i + bl[n].kmax*j + (k-1) + 1, 0);
    }
  fprintf(fp, "))\n");

  //################################################################################################
  this_zone_id++;
  fa_offset = fa_number+1;
  fa_number = fa_offset + bl[n].imax*bl[n].kmax-1;
  fprintf(fp,"(13 (%x %x %x %x %x)(\n", this_zone_id, fa_offset, fa_number, (int)FLUENT_TYPE_WALL, fa_element_type);
  j = 0;
  for (i=0; i<bl[n].imax; ++i)
    for (k=0; k<bl[n].kmax; ++k)
    {
      fprintf(fp,"%x ", 4); // number of nodes of face
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+0) + k + 1);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+0) + k + 2);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+1) + (bl[n].kmax+1)*(j+0) + k + 2);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+1) + (bl[n].kmax+1)*(j+0) + k + 1);
      fprintf(fp,"%x %x\n", bl[n].jmax*bl[n].kmax*i + bl[n].kmax*j + k + 1, 0);
    }
  fprintf(fp, "))\n");

  this_zone_id++;
  fa_offset = fa_number+1;
  fa_number = fa_offset + bl[n].imax*bl[n].kmax-1;
  fprintf(fp,"(13 (%x %x %x %x %x)(\n", this_zone_id, fa_offset, fa_number, (int)FLUENT_TYPE_WALL, fa_element_type);
  j = bl[n].jmax;
  for (i=0; i<bl[n].imax; ++i)
    for (k=0; k<bl[n].kmax; ++k)
    {
      fprintf(fp,"%x ", 4); // number of nodes of face
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+0) + k + 1);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+1) + (bl[n].kmax+1)*(j+0) + k + 1);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+1) + (bl[n].kmax+1)*(j+0) + k + 2);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+0) + k + 2);
      fprintf(fp,"%x %x\n", bl[n].jmax*bl[n].kmax*i + bl[n].kmax*(j-1) + k + 1, 0);
    }
  fprintf(fp, "))\n");

  //################################################################################################
  this_zone_id++;
  fa_offset = fa_number + 1;
  fa_number = fa_offset + bl[n].jmax*bl[n].kmax-1;
  fprintf(fp,"(13 (%x %x %x %x %x)(\n", this_zone_id, fa_offset, fa_number, (int)FLUENT_TYPE_WALL, fa_element_type);
  i = 0;
  for (j=0; j<bl[n].jmax; ++j)
    for (k=0; k<bl[n].kmax; ++k)
    {
      fprintf(fp,"%x ", 4); // number of nodes of face
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+0) + k + 1);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+1) + k + 1);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+1) + k + 2);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+0) + k + 2);
      fprintf(fp,"%x %x\n", bl[n].jmax*bl[n].kmax*i + bl[n].kmax*j + k + 1, 0);
    }
  fprintf(fp, "))\n");

  this_zone_id++;
  fa_offset = fa_number+1;
  fa_number = fa_offset + bl[n].jmax*bl[n].kmax-1;
  fprintf(fp,"(13 (%x %x %x %x %x)(\n", this_zone_id, fa_offset, fa_number, (int)FLUENT_TYPE_WALL, fa_element_type);
  i = bl[n].imax;
  for (j=0; j<bl[n].jmax; ++j)
    for (k=0; k<bl[n].kmax; ++k)
    {
      fprintf(fp,"%x ", 4); // number of nodes of face
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+0) + k + 1);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+0) + k + 2);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+1) + k + 2);
      fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+1) + k + 1);
      fprintf(fp,"%x %x\n", bl[n].jmax*bl[n].kmax*(i-1) + bl[n].kmax*j + k + 1, 0);
    }
  fprintf(fp, "))\n");

  //################################################################################################
  //################################################################################################
  this_zone_id++;
  fa_offset = fa_number+1;
  //  fa_number += bl[n].jmax*bl[n].kmax;
  fprintf(fp,"(13 (%x %x %x %x %x)(\n", this_zone_id, fa_offset, nfaces, (int)FLUENT_TYPE_INTERIOR, fa_element_type);

  for (i=0; i<bl[n].imax; ++i)
    for (j=0; j<bl[n].jmax; ++j)
      for (k=1; k<bl[n].kmax; ++k)
      {
        fprintf(fp,"%x ", 4); // number of nodes of face
        fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+0) + k + 1);
        fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+1) + k + 1);
        fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+1) + (bl[n].kmax+1)*(j+1) + k + 1);
        fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+1) + (bl[n].kmax+1)*(j+0) + k + 1);
        fprintf(fp,"%x %x\n", bl[n].jmax*bl[n].kmax*i + bl[n].kmax*j + k,
            bl[n].jmax*bl[n].kmax*i + bl[n].kmax*j + k+1);
      }

  for (i=0; i<bl[n].imax; ++i)
    for (j=1; j<bl[n].jmax; ++j)
      for (k=0; k<bl[n].kmax; ++k)
      {
        fprintf(fp,"%x ", 4); // number of nodes of face
        fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+0) + k + 1);
        fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+1) + (bl[n].kmax+1)*(j+0) + k + 1);
        fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+1) + (bl[n].kmax+1)*(j+0) + k + 2);
        fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+0) + k + 2);
        fprintf(fp,"%x %x\n", bl[n].jmax*bl[n].kmax*i + bl[n].kmax*(j-1) + k+1,
            bl[n].jmax*bl[n].kmax*i + bl[n].kmax*j     + k+1);
      }

  for (i=1; i<bl[n].imax; ++i)
    for (j=0; j<bl[n].jmax; ++j)
      for (k=0; k<bl[n].kmax; ++k)
      {
        fprintf(fp,"%x ", 4); // number of nodes of face
        fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+0) + k + 1);
        fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+0) + k + 2);
        fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+1) + k + 2);
        fprintf_(fp,"%x ", (bl[n].jmax+1)*(bl[n].kmax+1)*(i+0) + (bl[n].kmax+1)*(j+1) + k + 1);
        fprintf(fp,"%x %x\n", bl[n].jmax*bl[n].kmax*(i-1) + bl[n].kmax*j + k+1,
            bl[n].jmax*bl[n].kmax*i     + bl[n].kmax*j + k+1);
      }
  fprintf(fp, "))\n");

  //################################################################################################
  //################################################################################################

  fprintf(fp, "(39 (%d wall z0 1)())\n", 11);
  fprintf(fp, "(39 (%d wall z1 1)())\n", 12);
  fprintf(fp, "(39 (%d wall y0 1)())\n", 13);
  fprintf(fp, "(39 (%d wall y1 1)())\n", 14);
  fprintf(fp, "(39 (%d wall x0 1)())\n", 15);
  fprintf(fp, "(39 (%d wall x1 1)())\n", 16);
  fprintf(fp, "(39 (%d default-interior default-interior 1)())\n", 17);



  // start of nodes...
  fprintf(fp,"(0 \"Nodes:\")\n");
  fprintf(fp,"(10 (1 %x %x 1 3 )(\n",1,vertices);

  //
  // nodes
  //
  double scale = 1.0;//0.0254;//e-3;

  int indexBlock = 0;
  for (n=0; n<nbl; ++n)
  {
    for (i=0; i<=bl[n].imax; ++i)
      for (j=0; j<=bl[n].jmax; ++j)
        for (k=0; k<=bl[n].kmax; ++k)
          fprintf(fp, "%15.8e %15.8e %15.8e\n", bl[n].pt[i][j][k][0]*scale, bl[n].pt[i][j][k][1]*scale, bl[n].pt[i][j][k][2]*scale);

    indexBlock += (bl[n].imax+1)*(bl[n].jmax+1)*(bl[n].kmax+1);
  }

  fprintf(fp,"))\n");*/

  fclose(fp);
}


void UNSTRUCTMESH::readGambitNeu2D(const char *name)
{
  FILE *fp;
  if ((fp = fopen(name, "rt")) == NULL)
  {
    printf("couldn't open %s for reading\n", name);
    exit(-1);
  }

  // Read header
  char line[1000];
  fscanf(fp, "%s\n", line);
  while (strcmp(line, "NDFVL") != 0)    fscanf(fp, "%s\n", line);

  int ngrps, nbsets, ndfcd, ndfvl, dummy;
  int nvertices, nelements;
  fscanf(fp, "%i %i %i %i %i %i \n", &nvertices, &nelements, &ngrps, &nbsets, &ndfcd, &ndfvl);
//  if (ndfcd != 2)  // Check if it is indeed a 2D grid
//  {
//    printf(" The input file should be 3D but ndfcd = %i \n", ndfcd);
//    printf(" Exiting! \n");
//    exit(-1);
//  }
  printf(" %dD Grid --> Vertices: %i        Elements: %i \n", ndfcd, nvertices, nelements);

  // Allocate memory to save vertices and elements
  nodes.resize(nvertices);
  elems.resize(nelements);


  while (strcmp(line, GAMBIT_VER) != 0)    fscanf(fp, "%s\n", line);

  // Read nodal coordinates
  for (int i = 0; i < nvertices; i++)
  {
    fscanf(fp, "%10d%lf%lf%lf\n", &dummy, &nodes[i].pt.x, &nodes[i].pt.y, &nodes[i].pt.z);
//    if (i%100 == 0) printf("%10d\t%lf%lf%lf\n", dummy, nodes[i].pt.x, nodes[i].pt.y, nodes[i].pt.z);
  }

  fscanf(fp, "%s\n", line);
  while (strcmp(line, GAMBIT_VER) != 0)    fscanf(fp, "%s\n", line);

  // Read elements
  elem_i.push_back(0);

  for (int c = 0; c < nelements; c++)
  {
    int nvert, type;
    fscanf(fp, "%8i%2i%2i\n", &dummy, &type, &nvert);


    int nodes[10];

    if (type == NTYPE_TRI)
    {
      fscanf(fp, "%8i%8i%8i\n", &nodes[0], &nodes[1], &nodes[2]);
    }
    else if (type == NTYPE_QUAD)
    {
      fscanf(fp, "%8i%8i%8i%8i\n", &nodes[0], &nodes[1],
                                   &nodes[2], &nodes[3]);
    }
    else if (type == NTYPE_BRICK)
    {
      fscanf(fp, "%8i%8i%8i%8i%8i%8i%8i\n%10d\n",
          &nodes[0], &nodes[1], &nodes[2], &nodes[3],
          &nodes[4], &nodes[5], &nodes[6], &nodes[7]);
    }

    for (int ne=0; ne<nvert; ne++) elem_v.push_back(nodes[ne]-1);
    elem_i.push_back(elem_i[elem_i.size()-1]+nvert);
  }
  fclose(fp);

  printf("\n input file in Gambit Neutral format read! \n");
}

void UNSTRUCTMESH::readNastranMod(const char *name)
{
  FILE *fp;
  if ((fp = fopen(name, "rt")) == NULL)
  {
    printf("couldn't open %s for reading\n", name);
    exit(-1);
  }

  // Read header
//  char line[1000];
//  fscanf(fp, "%s\n", line);
//  while (strcmp(line, "NDFVL") != 0)    fscanf(fp, "%s\n", line);


  int nvertices, nelements;
  fscanf(fp, "%d\n%d\n", &nvertices, &nelements);

  printf(" NASTRAN Grid --> Vertices: %i        Elements: %i \n", nvertices, nelements);

  // Allocate memory to save vertices and elements
  nodes.resize(nvertices);
  elems.resize(nelements);


//  while (strcmp(line, GAMBIT_VER) != 0)    fscanf(fp, "%s\n", line);

  int dummy;
  char line[1000];

  // Read nodal coordinates
  for (int i = 0; i < nvertices; i++)
  {
    fscanf(fp, "%d%d%lf%lf\n", &dummy, &dummy, &nodes[i].pt.x, &nodes[i].pt.y);
    fscanf(fp, "%s\n", line);
    fscanf(fp, "%7s%lf\n", line, &nodes[i].pt.z);
//    printf("%lf\t%lf\t%lf\n", nodes[i].pt.x, nodes[i].pt.y, nodes[i].pt.z);
  }

//  throw(-112);


  // Read elements
  elem_i.push_back(0);

  for (int c = 0; c < nelements; c++)
  {
    int nodes[10];

    fscanf(fp, "%18s%d%d%d%d%d%d%d%d", line, &dummy, &dummy, &nodes[0], &nodes[1], &nodes[2], &nodes[3],&nodes[4], &nodes[5]);
    fscanf(fp, "%s\n", line);
    fscanf(fp, "%7s%d%d\n", line, &nodes[6], &nodes[7]);

//    for (int ne=0; ne<8; ne++) printf("%d\t", nodes[ne]);
//    printf("\n");

    for (int ne=0; ne<8; ne++) elem_v.push_back(nodes[ne]-1);
    elem_i.push_back(elem_i[elem_i.size()-1]+8);
  }
  fclose(fp);

  printf("\n input file in NASTRAN format read! \n");
}



void UNSTRUCTMESH::drawMesh()
{
  for (int e=0; e<elem_i.size()-1; e++)
	{
//    	glLineWidth(0.2);
    glBegin(GL_LINE_LOOP);
    {
      double grey = 0.5;
      glColor3d(0.0, 0.0, 0.0);


      for (int ne=elem_i[e]; ne<elem_i[e+1]-1; ne++)
      {
        glVertex3d(nodes[elem_v[ne]].pt.x,   nodes[elem_v[ne]].pt.y,   nodes[elem_v[ne]].pt.z);
        glVertex3d(nodes[elem_v[ne+1]].pt.x, nodes[elem_v[ne+1]].pt.y, nodes[elem_v[ne+1]].pt.z);
      }
    }
    glEnd();
//      glLineWidth(1.0);
  }

}

void UNSTRUCTMESH::drawSolid()
{
  for (int e=0; e<elem_i.size()-1; e++)
	{
    glBegin(GL_TRIANGLES);
    glColor3d(0.85, 0.85, 0.85);

    POINT t1 = nodes[elem_v[elem_i[e]]].pt;
    for (int ne=elem_i[e]; ne<elem_i[e+1]-1; ne++)
    {
      POINT t2 = nodes[elem_v[ne]].pt;
      POINT t3 = nodes[elem_v[ne+1]].pt;

      glVertex3d(t1.x, t1.y, t1.z);
      glVertex3d(t2.x, t2.y, t2.z);
      glVertex3d(t3.x, t3.y, t3.z);
    }
    glEnd();
  }
}




//=============================================
//        UNSTRUCTMESH CLASS FUNCTIONS
//=============================================

void TRIANGULATE::unstructuredMesh2D()
{
  struct triangulateio in, out, vorout;

  int Next = extBoundary.size();
  // ***********************
  // Define number of points
	in.numberofpoints = Next;

	if (holes.size()>0)
	{
		for (int i=0; i<holes.size(); i++)
			in.numberofpoints += holes[i].holesPoints.size();
	}
//		printf("number of points: %d\n",in.numberofpoints);


	// ****************************
	// Assign points [x y x y ....]
  in.pointlist = (REAL *) malloc(in.numberofpoints * 2 * sizeof(REAL));

	for (int i=0; i<2*extBoundary.size(); i=i+2)
	{
		// assign all the points
		in.pointlist[i]   = extBoundary[i/2].x;
		in.pointlist[i+1] = extBoundary[i/2].y;
	}
//		printf("External boundary points assigned\n");

  // HOLES
	if (holes.size()>0)
	{
		int N=0;
		for (int j=0; j<holes.size(); j++)
		{
			for (int i=0; i<holes[j].holesPoints.size()*2; i=i+2)
			{
				in.pointlist[Next*2+N+i]   = holes[j].holesPoints[i/2].x;
				in.pointlist[Next*2+N+i+1] = holes[j].holesPoints[i/2].y;
			}
			N += holes[j].holesPoints.size()*2;
		}
	}
//		printf("Hole assigned\n");


	// *****************************************************
	// Assign markers to points (1 means they are a boundary
  in.pointmarkerlist = (int *) malloc(in.numberofpoints * sizeof(int));
	for (int i=0; i<in.numberofpoints; i++)
		in.pointmarkerlist[i] = 1;
//		printf("point markers assigned\n");



	// ******************************************************************
	// Assign points attributes (can specify area for example). note used
	// point attributes
  in.numberofpointattributes = 1;
  in.pointattributelist = (REAL *) malloc(in.numberofpoints *
                                          in.numberofpointattributes *
                                          sizeof(REAL));
	for (int i=0; i<in.numberofpoints*in.numberofpointattributes; i++)
		in.pointattributelist[i] = 0.0;
//		printf("point attributes assigned\n");



	// *****************************************
	// Define segments [start end start end ...]
  in.numberofsegments = Next;
  if (holes.size()>0)
  	for (int i=0; i<holes.size(); i++)
  		in.numberofsegments += holes[i].holesPoints.size();

  printf("number of segments %d\n", in.numberofsegments);
  in.segmentlist = (int *) malloc(in.numberofsegments*2 * sizeof(int));

  int vert = 1;
  for (int i=0; i<Next*2; i=i+2)
  {
  	in.segmentlist[i] = vert;
  	in.segmentlist[i+1] = vert+1;
  	vert++;
  }
  in.segmentlist[2*Next-1] = 1;

  in.numberofholes = holes.size();

  // HOLES
  if (holes.size()>0)
  {
		int N=0;
		int sum=0;
		for (int j=0; j<holes.size(); j++)
		{
      sum += holes[j].holesPoints.size();
      vert = Next+N+1;
      for (int i=0; i<holes[j].holesPoints.size()*2; i=i+2)
      {
      	in.segmentlist[2*Next+N*2+i] = vert;
      	in.segmentlist[2*Next+N*2+i+1] = vert+1;
      	vert++;
      }
      in.segmentlist[2*Next+sum*2-1] = Next+N+1;
      N = holes[j].holesPoints.size();
		}
  }
//    printf("Holes segments assigned\n");


  // *********************************************
  // Define 1 point inside each hole [x y x y ...]
	in.holelist = (REAL *) malloc(in.numberofholes*2 * sizeof(REAL));
	for (int i=0; i<2*holes.size(); i=i+2)
	{
		in.holelist[i]   = holes[i/2].insidePoints.x;
		in.holelist[i+1] = holes[i/2].insidePoints.y;
	}


	// ******************************************
	// Segment markers (1 means it is a boundary)
  in.segmentmarkerlist = (int *) malloc(in.numberofsegments * sizeof(int));
	for (int i=0; i<in.numberofsegments; i++)
		in.segmentmarkerlist[i] = 1;
	printf("Segments markers assigned\n");

  in.numberofregions = 1;
  in.regionlist = (REAL *) malloc(in.numberofregions * 4 * sizeof(REAL));



  // **********************************
  // Initialize out and vorout as NULL
  out.pointlist = (double *) NULL;
  out.pointattributelist = (double *) NULL;
  out.pointmarkerlist = (int *) NULL;
  out.trianglelist = (int *) NULL;
  out.triangleattributelist = (double *) NULL;
  out.neighborlist = (int *) NULL;
  out.segmentlist = (int *) NULL;
  out.segmentmarkerlist = (int *) NULL;
  out.edgelist = (int *) NULL;
  out.edgemarkerlist = (int *) NULL;

  vorout.pointlist = (double *) NULL;
  vorout.pointattributelist = (double *) NULL;
  vorout.edgelist = (int *) NULL;
  vorout.normlist = (double *) NULL;


  // *******************************************************
  // Call to external function to generate unstructured mesh
  triangulate(triangParameters,&in, &out, &vorout);

  // *****************************************
  // Save data in POINT and TRIANGLE structure

  // assign nodes
  for (int i=0; i<2*out.numberofpoints; i=i+2)
  	push_back_node(POINT(out.pointlist[i], out.pointlist[i+1], extBoundary[0].z));

  for (int i=0; i<3*out.numberoftriangles; i++)
  	elem_v.push_back(out.trianglelist[i]-1);

  for (int i=0; i<=out.numberoftriangles; i++)
  	elem_i.push_back(3*i);

  // points are listed such that boundary points (marker = 1) are first in the array
  for (int i=0; i<out.numberofpoints; i++)
    nodes[i].marker = out.pointmarkerlist[i];


  if (holes.size()<=0)
  {
  	moveBoundaryNodesEnd(extBoundary);
  	moveBoundaryElementsEnd(extBoundary);
  }
  else
  {
  	deque<POINT> completeBoundary;
  	completeBoundary = extBoundary;
  	for (int h=0; h<holes.size(); h++)
  		{
  			completeBoundary.insert(completeBoundary.end(), holes[h].holesPoints.begin(), holes[h].holesPoints.end());
  			completeBoundary.push_back(holes[h].holesPoints[0]);
  		}

  	moveBoundaryNodesEnd(completeBoundary);
  	moveBoundaryElementsEnd(completeBoundary);
  }

  findNodeNeighbors();
}
